/*
 ============================================================================
 Name        : cmd.h
 Author      : Michael Bieringer
 Version     : 1.0
 Description : FHS Shell, Professional Programmer, Operation Systems
 Zweck: Headerdatei fuer das Shell Hauptprogramm
 ============================================================================
 */
// Definition der Kommandos welche interpretiert werden koennen
const char * cmdExit = "exit";       // Shell soll beendet werden
const char * cmdCurrDir = "pwd";     // Ausgabe aktuelles Verzeichnis auf stdout
const char * cmdFHSDate = "fhsdate"; // Ausgabe aktuelles Datum auf stdout
const char * cmdFHSTime = "fhstime"; // Ausgabe aktuelle Uhrzeit auf stdout
const char * cmdHelp = "help";       // Ausgabe der Hilfe-Information auf stdout
const char * cmdChangeDir = "cd";    // Aendern des aktuellen Verzeichnisses
const char * cmdEcho = "echo";       // Ausgabe von Text auf stdout
const char * cmdPushDir = "pushdir"; // Ablegen eines Verzeichnisses
const char * cmdPopDir = "popdir";   // Auslesen des Verzeichnisses welches mit pushdir abgelegt wurde
const char * cmdListDir = "ls";	     // Zeige das Inhaltsverzeichnis an
const char * cmdGetLCode = "echo$?";// Gibt den Errorcode des zuletzt ausgefuehrten Befehls aus
// Ende Definition Kommandos

// Definition Farbausgabe printf()
#define NORMAL_COLOR  "\x1B[0m"
#define GREEN         "\x1B[32m"
#define BLUE          "\x1B[34m"
#define MANGAN        "\x1B[35m"
// Ende Definition Farbausgabe

// Bitmaske fuer die ls Parameter
#define MASK_LS_NOTHING 0 // ls Befehl wurde ohne Parameter aufgerufen
#define MASK_LS_a       1 // ls Befehl wurde mit Parameter 'a' aufgerufen
#define MASK_LS_l       2 // ls Befehl wurde mit Parameter 'l' aufgerufen
// Ende Bitmaske fuer ls

// Definition der Rueckgabe-Werte der Parsing Funktion
#define RET_PARSE_CMD_SYS -12    // Aufruf von system(command)
#define RET_PARSE_CMD_NOT_SET -5 // Eingabe enthaelt nur Wert(e) von DELIMS
#define RET_PARSE_CMD_ERROR -2   // Fehler beim Lesen der Eingabe (falscher Parameter)
#define RET_PARSE_CMD_UNKNOWN -1 // Eingabe unbekannt
#define RET_PARSE_CMD_OK 0       // Eingabe konnte erfolgreich verarbeitet werden
#define RET_PARSE_CMD_EXIT 1     // Der Befehl zum Beenden der Shell
// Ende Definition Rueckgabe-Werte

// Definition Rueckgabe-Werte fuer FORK
#define RET_FORK_ERR -1
// Ende Definition Rueckgabe-Werte fuer FORK

#define MAX_EXECV_ARR_LEN 255 // Maximale Anzahl Parameter welche fuer execv mit uebergeben werden duerfen
#define MAX_LENGTH 1024   // Puffer fuer die Eingabe
#define DELIMS " \t\r\n"  // Trennzeichen-Erkennung zwischen den Parametern
#define ECHO_DELIMS " \t" // Trennzeichen-Erkennung fuer den echo Befehl
#define PARAM_DELIM " /-"

// Methode, welche das aktuelle Datum und Uhrzeit zurueck liefert
struct tm * getTimeInfo(void)
{
    time_t rawtime;
    time ( &rawtime );
    return localtime ( &rawtime );
}

void showHelp(void);          // Methode, welche die Hilfe auf stdout ausgibt
int parseInput(char * input, char * envp[]); // Methode, welche die Eingabe verarbeitet. Rueckgabewerte siehe RET_PARSE_CMD_*
int execute(char * command, char * params[]);		  // Kind-Prozess erzeugen
void removeSubstring(char *s,const char *toremove); // Entfernt einen substring in einem String
bool fileExist(char * path); // Prueft, ob eine Datei existiert
bool findExecutable(char * values, char * found, char * command); // sucht nach dem kompletten Pfad zu einem Programm (verwendet Environment-Variable PATH)
bool startsWith(const char * search, const char * complete); //Ueberprueft, ob ein String mit einer bestimmten Zeichenkette beginnt
void printFHSTime(void); // Ausgabe aktuelle Uhrzeit auf stdout
void printFHSDate(void); // Ausgabe aktuelles Datum auf stdout
int changeDir(const char * newDir, bool pushDirOnly); //aendert das aktuelle Verzeichnis oder speichert das Verzeichnis zwischen
int show_dir_content(const char * path, int params); //gibt den Inhalt des angegebene Verzeichnisses auf stdout aus
void printDirectoryShort(DIR * d, bool hidePointDirs); //gibt eine Kurzform des Verzeichnisinhaltes eines Verzeichnisses auf stdout aus
void printfFileRights(__mode_t st_mode); //gibt den Dateirechte einer Datei auf stdout aus
void printGroupUser(__gid_t gid); // gibt den Gruppennamen der Datei auf stdout aus
void printUserUser(__uid_t uid); // gibt die Benuternamen der Datei auf stdout aus
void printLinkInfo(__nlink_t nlink_t); // gibt die Anzahl der Links einer Datei formatiert auf stdout aus
void printFileDate(const time_t mtime); // gibt das Datum der Datei formatiert auf stdout aus
void printFileSize(__off_t size); // gibt die Groesse der Datei formatiert auf stdout aus
void printFileName(struct stat st, const char * d_name); // gibt den Dateinamen auf stdout aus
