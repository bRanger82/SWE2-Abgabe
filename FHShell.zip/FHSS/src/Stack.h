/*
 ============================================================================
 Name        : Stack.h
 Author      : Michael Bieringer
 Version     : 1.0
 Description : FHS Shell, Professional Programmer, Operation Systems
 Zweck: Headerdatei fuer Stack.c
 ============================================================================
 */

/* Prototypes fuer Stack */
void * push(void * data); //fuege element hinzu
void * pop(void);       //lese element und entferne es aus dem Stack
void * top(void);       //lese oberstes element ohne es zu entfernen
bool Sempty(void);       //prueft, ob der stack leer ist
int Slength (void);        //Maximale laenge des Stacks
void Sdelete(void);      //Zuruecksetzen des Stack und Inhalt wird loeschen
