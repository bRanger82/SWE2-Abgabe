/*
 ============================================================================
 Name        : SList.h
 Author      : Michael Bieringer
 Version     : 1.0
 Description : FHS Shell, Professional Programmer, Operation Systems
 Zweck: Headerdatei fuer die SList.c
 ============================================================================
 */
struct SList
{
    void * Data;
    struct SList *Next;
    struct SList *Prev;
}; typedef struct SList SLIST;

struct SList_Header
{
    int Len;
    SLIST *First, *Last;
}; typedef struct SList_Header SLIST_HEADER;

extern SLIST_HEADER *createSList(void); // Header von Liste erstellen
extern SLIST *insertFirst(SLIST_HEADER*,void *); // Element am Beginn hinzufuegen
extern SLIST *insertLast(SLIST_HEADER*,void*); // Element am Ende hinzufuegen
extern void *deleteFirst(SLIST_HEADER*); // Element am Beginn auslesen und es zugleich aus der Liste entfernen
extern void *deleteLast(SLIST_HEADER*); // Element am Ende auslesen und es zugleich aus der Liste entfernen
extern void rm_SList(SLIST_HEADER*); //Liste aus dem Speicher entfernen
