/*
 ============================================================================
 Name        : SList.c
 Author      : Michael Bieringer
 Version     : 1.0
 Description : FHS Shell, Professional Programmer, Operation Systems
 Zweck: Enthaelt die Funktionen und Prozeduren um eine Liste zu erstellen, verwalten und zu loeschen
 ============================================================================
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "SList.h"


SLIST_HEADER * createSList(void)
{
    SLIST_HEADER * p = (SLIST_HEADER *) malloc(sizeof(SLIST_HEADER));
    if (NULL == p)
    {
        return p;
    }

    p->Len = 0;
    p->First = NULL;
    p->Last = NULL;

    return p;
}

SLIST * insertFirst(SLIST_HEADER * head, void * data)
{
    SLIST * element = (SLIST *) malloc(sizeof(SLIST));
    if (NULL == element)
    {
        return element;
    }

    if (0 == head->Len)
    {
        element->Next = NULL;
        head->Last = element;
    } else
    {
        element->Next = head->First;
    }


    element->Data = data;

    head->First = element;
    head->Len++;

    return element;
}



/**
 * Lokale OPERATIONEN, die privat gehalten werden.
 *------------------------------------------------*/

static SLIST * makeSListNode (void * userData, SLIST * aPtr)
{
   SLIST * newPtr;    /* Zeiger auf zugewiesenen Speicher */

   if ((newPtr=(SLIST *) malloc(sizeof(SLIST))) != NULL)
   {
      newPtr->Data = userData;
      newPtr->Next = aPtr;
   }
   return (newPtr);
}

/* -- Am Ende der Liste eintragen */
SLIST * insertLast(SLIST_HEADER* aList, void* userData)
{
    SLIST * newPtr;

    if ((newPtr = makeSListNode(userData, (SLIST*) NULL))!= NULL)
    {
      if (aList->Len != 0)  /* -- Liste nicht leer ? */
        aList->Last->Next= newPtr;
      else
        aList->First= newPtr;

      aList->Last= newPtr;
      aList->Len++;
    }

    return (newPtr);
}


/* -- Loeschen des ersten Listeneintrages
 * -- aList->Len muss  vorher  ueberprueft werden
 */
void * deleteFirst(SLIST_HEADER* aList)
{
   SLIST *temp;

   if (aList->Len > 0)   /* Liste nicht leer */
   {
      temp= aList->First;
      void  *userData= temp->Data;

      aList->First= temp->Next;
      aList->Len--;

      if (aList->Len == 0) /* Wenn die Liste leer ist, Last-Zeiger auf NULL */
         aList->Last= (SLIST *) NULL;

      free( (void *) temp);         /* Knoten freigeben */
      return userData;
   }
   return NULL;
}


/* -- Loeschen des letzten Listeneintrages
 * -- aList->Len muss  vorher  ueberprueft werden
 */
void * deleteLast(SLIST_HEADER * aList)
{
   SLIST *temp, *help;
   void  *userData = NULL;
   int i;

   if (aList->Len > 0)   /* Liste nicht leer */
   {
      temp= aList->Last;
      userData= temp->Data;

      help= aList->First;
      aList->Last= help;
      for (i=0; i<aList->Len-1; i++){
         aList->Last= help;
         help= help->Next;
      }
      aList->Len--;

      if (aList->Len == 0) /* Wenn die Liste leer ist, Last-Zeiger auf NULL*/
      {
         aList->Last= (SLIST *) NULL;
         aList->First= (SLIST *) NULL;
      }
      free( (void *) temp);         /* Knoten freigeben */
   }
   return  userData;
}






void rm_SList(SLIST_HEADER* aList)
{
    while (aList->Len)
      deleteLast(aList);

    free (aList); /* alle Knoten geloescht, Header noch freigeben */
}


